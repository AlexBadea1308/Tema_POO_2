#include "ACharacter.h"

ACharacter::ACharacter(std::string name, CRace* race, CClase* clase):m_name(name),m_race(race),m_clase(clase)
{
	m_hp = 100;
	m_AttackAbilities.push_back(race->getAttackAbility());
	m_AttackAbilities.push_back(clase->getAttackAbility());
}

ACharacter::~ACharacter(){}