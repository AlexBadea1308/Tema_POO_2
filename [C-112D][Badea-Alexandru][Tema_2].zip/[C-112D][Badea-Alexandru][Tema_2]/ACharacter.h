#pragma once
#include<utility>
#include"CClase.h"
#include"CRace.h"
#include<vector>
class ACharacter
{
protected:
	std::string m_name;
	CRace* m_race;
	CClase* m_clase;
	int m_hp;
	std::vector < std::pair<std::string, int>> m_AttackAbilities;
public:
	ACharacter(){};
	ACharacter(std::string enemy_name, CRace* race, CClase* clase);
	virtual void displayInfo(std::ofstream& file)=0;
	virtual int getHP()=0;
	virtual void subHP(int dammage)=0;
	virtual std::vector < std::pair<std::string, int>>& getAbilities()=0;
	virtual std::string getName()=0;
	virtual ~ACharacter();
	virtual bool rollAbilityCheck(int difficultyClass, std::string ability, std::ofstream& file) = 0;
};

