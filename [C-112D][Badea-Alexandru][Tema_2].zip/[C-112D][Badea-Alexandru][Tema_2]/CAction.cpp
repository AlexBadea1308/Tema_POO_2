#include "CAction.h"

std::string CAction::getNameAction()const
{
    return m_name_action;
}

std::string CAction::getNameObject()const
{
    return m_object;
}

int CAction::getDifficultyClass()const
{
    return m_DC_action;
}

std::string CAction::getAbility()const
{
    return m_need_ability;
}