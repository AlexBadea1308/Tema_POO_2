#pragma once
#include<string>
class CAction
{
private:
    std::string m_name_action;
    std::string m_object;
    int m_DC_action;
    std::string m_need_ability;
public:
    CAction(std::string name, std::string object,int difficultyClass,std::string ability):m_name_action(name), m_object(object),m_DC_action(difficultyClass),m_need_ability(ability){}
    std::string getNameAction()const;
    std::string getNameObject()const;
    int getDifficultyClass()const;
    std::string getAbility()const;
};