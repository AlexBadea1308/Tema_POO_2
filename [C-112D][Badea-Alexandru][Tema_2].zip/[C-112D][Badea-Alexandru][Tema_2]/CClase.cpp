#include "CClase.h"
#include<string>

std::string& CClase::get_clase_name()
{
	return m_clase_name;
}