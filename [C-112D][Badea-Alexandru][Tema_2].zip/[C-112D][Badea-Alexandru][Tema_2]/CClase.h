#pragma once
#include<string>
class CClase
{
private:
	std::string m_clase_name;
public:
	CClase(std::string clase_name):m_clase_name(clase_name){}
	std::string& get_clase_name();
	virtual int getPlusDexterity() { return 0; };
	virtual int getPlusIntelligence() { return 0; };
	virtual int getPlusStrength() { return 0; };
	virtual int getPlusHealth() { return 0; };
	virtual std::pair<std::string, int> getAttackAbility() { return std::make_pair("", 0); };
};

