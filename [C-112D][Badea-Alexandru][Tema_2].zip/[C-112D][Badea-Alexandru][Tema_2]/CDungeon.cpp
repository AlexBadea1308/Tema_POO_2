#include "CDungeon.h"

std::vector<std::pair<CAction,std::string>>& CDungeon::getActionsFromDungeon()
{
	return m_actions;
}

std::string CDungeon::getDungeonName()const
{
	return m_Dungeon_name;
}