#pragma once
#include"CAction.h"
#include<string>
#include<vector>
class CDungeon
{
private:
    std::string m_Dungeon_name;
    std::vector<std::pair<CAction,std::string>> m_actions;
public:
    CDungeon(std::string name,const std::vector<std::pair<CAction,std::string>>& actions):m_Dungeon_name(name),m_actions(actions){}
    std::vector<std::pair<CAction,std::string>>& getActionsFromDungeon();
    std::string getDungeonName()const;
};