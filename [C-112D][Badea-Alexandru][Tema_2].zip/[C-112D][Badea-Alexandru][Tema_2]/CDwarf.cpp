#include "CDwarf.h"

int CDwarf::getPlusHealth()
{
    return m_plus_health;
}

int CDwarf::getPlusDexterity()
{
    return m_plus_dexterity;
}

std::pair<std::string, int> CDwarf::getAttackAbility()
{
    return m_attack_ability;
}