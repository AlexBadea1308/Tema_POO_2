#pragma once
#include "CRace.h"
class CDwarf :public CRace
{
private:
	int m_plus_dexterity;
	int m_plus_health;
	std::pair<std::string, int> m_attack_ability;
public:
	CDwarf(std::string race_name, int plus_dexteriry, int plus_health) :CRace(race_name), m_plus_dexterity(plus_dexteriry), m_plus_health(plus_health),m_attack_ability(std::make_pair("Lowblow",25)){}
	int getPlusHealth()override;
	int getPlusDexterity()override;
	std::pair<std::string, int> getAttackAbility()override;
};

