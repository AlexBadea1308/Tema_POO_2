#include "CDwarfFactory.h"
#include"CDwarf.h"

CRace* CDwarfFactory::createRace()
{
	return new CDwarf("Dwarf", 3,-2);
}
