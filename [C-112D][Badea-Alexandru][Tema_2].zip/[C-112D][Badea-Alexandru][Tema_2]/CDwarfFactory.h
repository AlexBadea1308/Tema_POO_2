#pragma once
#include "IRaceFactory.h"
#include<string>
class CDwarfFactory :public IRaceFactory
{
public:
	CRace* createRace()override;
};

