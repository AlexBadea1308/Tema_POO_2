#include "CElf.h"

int CElf::getPlusDexterity()
{
	return m_plus_dexterity;
}

std::pair<std::string, int> CElf::getAttackAbility()
{
	return m_attack_ability;
}