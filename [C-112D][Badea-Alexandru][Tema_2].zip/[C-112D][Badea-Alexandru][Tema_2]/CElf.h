#pragma once
#include "CRace.h"
class CElf :public CRace
{
private:
	int m_plus_dexterity;
	std::pair<std::string, int> m_attack_ability;
public:
	CElf(std::string race_name, int plus_dexteriry):CRace(race_name), m_plus_dexterity(plus_dexteriry),m_attack_ability(std::make_pair("Spear",20)){}
	int getPlusDexterity()override;
	std::pair<std::string, int> getAttackAbility()override;
};