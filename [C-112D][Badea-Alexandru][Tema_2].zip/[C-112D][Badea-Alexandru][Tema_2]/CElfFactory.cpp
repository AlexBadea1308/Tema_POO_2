#include "CElfFactory.h"

CRace* CElfFactory::createRace()
{
	return new CElf("Elf", 4);
}
