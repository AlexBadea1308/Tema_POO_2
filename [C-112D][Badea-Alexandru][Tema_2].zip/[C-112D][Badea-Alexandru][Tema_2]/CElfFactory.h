#pragma once
#include "IRaceFactory.h"
#include "CElf.h"
class CElfFactory :public IRaceFactory
{
public:
	CRace* createRace()override;
};

