#include "CEnemies.h"
#include<iostream>
#include<fstream>
#include <chrono>
#include <thread>

CEnemies::CEnemies(std::string name, CRace* race, CClase* clase) :ACharacter(name, race, clase)
{
	m_hp = 120;
}

int CEnemies::getHP()
{
	return m_hp;
}

void CEnemies::subHP(int dammage)
{
	m_hp -= dammage;
}

std::vector<std::pair<std::string, int>>& CEnemies::getAbilities()
{
	return m_AttackAbilities;
}

std::string CEnemies::getName()
{
	return m_name;
}

void CEnemies::displayInfo(std::ofstream& file)
{
	file << "Name: " << m_name << std::endl << "Race: " << m_race->get_race_name() << std::endl << "Class: " << m_clase->get_clase_name()<<std::endl<<"HP: "<<m_hp<<std::endl;
	std::cout << "Name: " << m_name << std::endl << "Race: " << m_race->get_race_name() << std::endl << "Class: " << m_clase->get_clase_name()<<std::endl<<"HP: "<<m_hp<<std::endl;
	file << m_name << " has this attack abilities:" << std::endl;
	std::cout << m_name << " has this attack abilities:" << std::endl;

	for (std::vector<std::pair<std::string, int>>::iterator it = m_AttackAbilities.begin(); it != m_AttackAbilities.end(); it++)
	{
		file << "<" << (*it).first << ">" << "--->" << (*it).second << " damage" << std::endl;
		std::cout << "<" << (*it).first << ">" << "--->" << (*it).second << " damage" << std::endl;
	}
	file << std::endl;
	std::cout << std::endl;
}

bool CEnemies::rollAbilityCheck(int difficultyClass, std::string ability, std::ofstream& file)
{
	// Simulam aruncarea zarurilor si aplicam modificarile
		int roll = rand() % 20 + 1;
		std::this_thread::sleep_for(std::chrono::seconds(1));
		file << "<DungeonMaster>:Your enemy need to roll at least " << difficultyClass << " to pass the quest!" << std::endl;
		std::cout << "<DungeonMaster>:Your enemy need to roll at least " << difficultyClass << " to pass the quest!" << std::endl;
		// Afisam rezultatul
		std::this_thread::sleep_for(std::chrono::seconds(1));
		file << "<DungeonMaster>:" << m_name<< " roll a " << roll << " on a d20 for " << ability << " check. Result: " << roll << std::endl;
		std::cout << "<DungeonMaster>:" << m_name<< " roll a " << roll << " on a d20 for " << ability << " check. Result: " << roll<< std::endl;

		//returnam 1 daca am acumulat un nr mai mare decat difficultyClass ul sau 0 in caz contrar
		return roll >= difficultyClass;
}

CEnemies::~CEnemies()
{
}