#pragma once
#include"ACharacter.h"
#include<vector>

class CEnemies:public ACharacter
{
public:
	CEnemies(){};
	CEnemies(std::string name, CRace* race, CClase* clase);
	int getHP()override;
	void subHP(int dammage)override;
	std::vector < std::pair<std::string, int>>& getAbilities()override;
	std::string getName()override;
	void displayInfo(std::ofstream& file)override;
	bool rollAbilityCheck(int difficultyClass, std::string ability, std::ofstream& file)override;
	~CEnemies();
};