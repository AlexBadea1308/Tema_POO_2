#include "CExceptions.h"
#include<iostream>

void CExceptions::printErrorMessage(std::ofstream& file)
{
	file<<"ERORR FOUND with code " << (m_code) << "----->" << m_message << "!" << std::endl << std::endl;
}
