#pragma once
#include<string>
#include<fstream>
class CExceptions
{
private:
	std::string m_message;
	int m_code;
public:
	CExceptions(std::string message,int code):m_message(message),m_code(code){}
	void printErrorMessage(std::ofstream& file);
	~CExceptions() {};
};

