#include "CFightFactory.h"

CClase* CFightFactory::createClase()
{
    return new CFighter("Fighter",2,10);
}
