#pragma once
#include "IClaseFactory.h"
#include "CFighter.h"
class CFightFactory :public IClaseFactory
{
public:
	CClase* createClase()override;
};

