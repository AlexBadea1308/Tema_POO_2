#include "CFighter.h"

int CFighter::getPlusStrength()
{
    return m_plus_strength;
}

int CFighter::getPlusHealth()
{
    return m_plus_health;
}

std::pair<std::string, int> CFighter::getAttackAbility()
{
    return m_attack_ability;
}