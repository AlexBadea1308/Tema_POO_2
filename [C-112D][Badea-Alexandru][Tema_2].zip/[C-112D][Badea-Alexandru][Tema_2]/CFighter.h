#pragma once
#include "CClase.h"
class CFighter :public CClase
{
private:
	int m_plus_strength;
	int m_plus_health;
	std::pair<std::string, int> m_attack_ability;
public:
	CFighter(std::string clase_name,int plus_strength,int plus_health):CClase(clase_name),m_plus_health(plus_health),m_plus_strength(plus_strength), m_attack_ability(std::make_pair("SuperManPunch",25)) {}
	int getPlusStrength()override;
	int getPlusHealth()override;
	std::pair<std::string, int> getAttackAbility()override;
};

