#include "CHuman.h"

int CHuman::getPlusDexterity()
{
    return m_plus_dexterity;
}

int CHuman::getPlusIntelligence()
{
    return m_plus_intelligence;
}

std::pair<std::string, int> CHuman::getAttackAbility()
{
    return m_attack_ability;
}
