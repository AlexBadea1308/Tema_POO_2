#pragma once
#include "CRace.h"
class CHuman :public CRace
{
private:
	int m_plus_dexterity;
	int m_plus_intelligence;
	std::pair<std::string, int> m_attack_ability;
public:
	CHuman(std::string race_name,int plus_dexteriry,int plus_intelligence):CRace(race_name),m_plus_dexterity(plus_dexteriry),m_plus_intelligence(plus_intelligence),m_attack_ability(std::make_pair("Hook",30)){}
	int getPlusDexterity()override;
	int getPlusIntelligence()override;
	std::pair<std::string, int> getAttackAbility()override;
};

