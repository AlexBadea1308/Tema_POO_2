#include "CHumanFactory.h"

CRace* CHumanFactory::createRace()
{
    return new CHuman("Human",-2,4);
}
