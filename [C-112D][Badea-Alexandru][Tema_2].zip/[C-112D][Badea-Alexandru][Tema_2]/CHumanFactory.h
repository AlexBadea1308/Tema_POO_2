#pragma once
#include "IRaceFactory.h"
#include "CHuman.h"
class CHumanFactory :public IRaceFactory
{
	public:
		CRace* createRace()override;
};

