#include "CMonk.h"

int CMonk::getPlusHealth()
{
    return m_plus_health;
}

int CMonk::getPlusIntelligence()
{
    return m_plus_intelligence;
}

std::pair<std::string, int> CMonk::getAttackAbility()
{
    return m_attack_ability;
}