#pragma once
#include "CClase.h"
class CMonk :public CClase
{
private:
	int m_plus_intelligence;
	int m_plus_health;
	std::pair<std::string, int> m_attack_ability;
public:
	CMonk(std::string clase_name, int plus_intelligence, int plus_health) :CClase(clase_name), m_plus_health(plus_health), m_plus_intelligence(plus_intelligence), m_attack_ability(std::make_pair("Kick",10)) {}
	int getPlusHealth()override;
	int getPlusIntelligence()override;
	std::pair<std::string, int> getAttackAbility()override;
};

