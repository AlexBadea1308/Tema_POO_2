#include "CMonkFactory.h"

CClase* CMonkFactory::createClase()
{
    return new CMonk("Monk",3,-1);
}
