#pragma once
#include "IClaseFactory.h"
#include"CMonk.h"
class CMonkFactory : public IClaseFactory
{
public:
	CClase* createClase()override;
};

