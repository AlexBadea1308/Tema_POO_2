﻿#include "CPlayer.h"
#include<fstream>
#include<iostream>
#include<string>
#include<utility>
#include<vector>
#include <chrono>
#include <thread>

CPlayer::CPlayer(){}

CPlayer::CPlayer(std::string name, CRace* race, CClase* clase):ACharacter(name,race,clase),
m_strength(std::make_pair(rand()%10+11,0)),
m_intelligence(std::make_pair(rand()%10+11,0)),// generam abilitati random pentru strength,intelligence,dexterity
m_dexterity(std::make_pair(rand()%10+11,0)),
m_level(1), m_experience(0){}

void CPlayer::displayInfo(std::ofstream& file)
{  
	file<< "Name: " << m_name <<std::endl<<"Race: " << m_race->get_race_name() <<std::endl<<"Class: " << m_clase->get_clase_name()
		<<std::endl<<"Level: " << m_level <<std::endl<<"Experience: " << m_experience <<std::endl<< "Health Points: " << m_hp
		<<std::endl<<"Strength: " << m_strength.first << " (Modifier: " << m_strength.second << ")"
		<<std::endl<<"Intelligence: " << m_intelligence.first << " (Modifier: " << m_intelligence.second << ")"
		<<std::endl<<"Dexterity: " << m_dexterity.first << " (Modifier: " << m_dexterity.second << ")" << std::endl;

	std::cout << "Name: " << m_name << std::endl << "Race: " << m_race->get_race_name() << std::endl << "Class: " << m_clase->get_clase_name()
		<< std::endl << "Level: " << m_level << std::endl << "Experience: " << m_experience << std::endl << "Health Points: " << m_hp
		<< std::endl << "Strength: " << m_strength.first << " (Modifier: " << m_strength.second << ")"
		<< std::endl << "Intelligence: " << m_intelligence.first << " (Modifier: " << m_intelligence.second << ")"
		<< std::endl << "Dexterity: " << m_dexterity.first << " (Modifier: " << m_dexterity.second << ")" << std::endl;

	file<< m_name << " has this attack abilities:" << std::endl;

	std::cout << m_name << " has this attack abilities:" << std::endl;

	for (std::vector<std::pair<std::string, int>>::iterator it = m_AttackAbilities.begin(); it != m_AttackAbilities.end(); it++)
	{
		file<< "<" << (*it).first << ">" << "--->" << (*it).second << " damage" << std::endl;

		std::cout << "<" << (*it).first << ">" << "--->" << (*it).second << " damage" << std::endl;
	}
	file<<std::endl;

	std::cout <<std::endl;
}

void CPlayer::levelUp(std::ofstream& file)
{
	m_level++;
	m_hp += 10;
	file<< m_name << " leveled up to level " << m_level << "!"<<std::endl<<std::endl;
	std::cout << m_name << " leveled up to level " << m_level << "!"<<std::endl<<std::endl;
	displayInfo(file);
}

void CPlayer::gainExperience(int exp, std::ofstream& file)
{
	m_experience += exp;
	file<< m_name << " gained " << exp << " experience points!"<<std::endl<<std::endl;
	std::cout << m_name << " gained " << exp << " experience points!"<<std::endl<<std::endl;
	// Verificam daca jucatorul a atins un nivel nou
	if (m_experience >= m_level * 100) 
	{
		m_experience -= m_level * 100;
		levelUp(file);
	}
}

void CPlayer::updateAbilities()
{
	if (m_race->get_race_name() == "Elf")
	{
		m_dexterity.first+= m_race->getPlusDexterity();
	}
	else
	{
		if (m_race->get_race_name() == "Human")
		{
			m_dexterity.first += m_race->getPlusDexterity();
			m_intelligence.first += m_race->getPlusIntelligence();
		}
		else
		{
			if (m_race->get_race_name() == "Dwarf")
			{
				m_dexterity.first += m_race->getPlusDexterity();
				m_hp += m_race->getPlusHealth();
			}
		}
	}


	if (m_clase->get_clase_name() == "Wizard")
	{
		m_intelligence.first += m_clase->getPlusIntelligence();
		m_strength.first += m_clase->getPlusStrength();
	}
	else
	{
		if (m_clase->get_clase_name() == "Fighter")
		{
			m_hp += m_clase->getPlusHealth();
			m_strength.first += m_clase->getPlusStrength();
		}
		else
			if (m_clase->get_clase_name() == "Monk")
			{
				m_intelligence.first += m_clase->getPlusIntelligence();
				m_hp += m_clase->getPlusHealth();
			}
	}
}

void CPlayer::updateModifier()
{
	m_intelligence.second=(m_intelligence.first - 10) / 2;
	m_dexterity.second = (m_dexterity.first - 10) / 2;
	m_strength.second = (m_strength.first -10) / 2;
}

std::pair<int, int> CPlayer::getStrength()const
{
	return m_strength;
}

std::pair<int, int> CPlayer::getIntelligence()const
{
	return m_intelligence;
}

std::pair<int, int> CPlayer::getDexterity()const
{
	return m_dexterity;
}

std::string CPlayer::getName()
{
	return m_name;
}

std::vector<std::pair<std::string, int>>& CPlayer::getAbilities()
{
	return m_AttackAbilities;
}

int CPlayer::getHP()
{
	return m_hp;
}

void CPlayer::subHP(int dammage)
{
	m_hp -= dammage;
}

bool CPlayer::rollAbilityCheck(int difficultyClass, std::string ability, std::ofstream& file)
{
	// Simulam aruncarea zarurilor si aplicam modificarile
	try
	{
		int roll = rand() % 20 + 1;
		int modifier = 0;

		if (ability == "Strength") {
			modifier = m_strength.second;
		}
		else if (ability == "Intelligence") {
			modifier = m_intelligence.second;
		}
		else if (ability == "Dexterity") {
			modifier = m_dexterity.second;
		}
		if (modifier + 20 < difficultyClass)
		{
			throw CExceptions("ERORR action impossible to complete! Difficulty class to big", 87654);
		}
		int result = roll + modifier;

		std::this_thread::sleep_for(std::chrono::seconds(1));
		file << "<DungeonMaster>:You need to roll at least " << difficultyClass << " to pass the quest!" << std::endl;
		std::cout << "<DungeonMaster>:You need to roll at least " << difficultyClass << " to pass the quest!" << std::endl;
		// Afisam rezultatul
		std::this_thread::sleep_for(std::chrono::seconds(1));
		file << "<DungeonMaster>:" << m_name << " roll a " << roll << " on a d20 for " << ability << " check. Result: " << result << std::endl;
		std::cout << "<DungeonMaster>:" << m_name<< " roll a " << roll << " on a d20 for " << ability << " check. Result: " << result << std::endl;
		//returnam 1 daca am acumulat un nr mai mare decat difficultyClass ul sau 0 in caz contrar
		return result >= difficultyClass;
	}
	catch (CExceptions e)
	{
		throw;
	}
}

void CPlayer::addHP(int addons)
{
	m_hp = 100 + addons;
}

void CPlayer::addIntelligence(int addons)
{
	m_intelligence.first += addons;
}

void CPlayer::addDexterity(int addons)
{
	m_dexterity.first+= addons;
}

void CPlayer::addStrength(int addons)
{
	m_strength.first += addons;
}

CPlayer::~CPlayer(){}