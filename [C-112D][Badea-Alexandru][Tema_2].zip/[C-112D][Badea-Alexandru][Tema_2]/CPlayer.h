#pragma once
#include "ACharacter.h"
#include"CExceptions.h"
#include<utility>
#include<vector>
class CPlayer:public ACharacter
{
private:
	int m_level;
	int m_experience;
	//Ability score,Modifier
	std::pair<int, int> m_strength;
	std::pair<int, int> m_intelligence;
	std::pair<int, int> m_dexterity;
public:
	CPlayer();
	CPlayer(std::string name, CRace* race, CClase* clase);
	void displayInfo(std::ofstream& file)override;
	void levelUp(std::ofstream& file);
	void gainExperience(int exp, std::ofstream& file);
	void updateAbilities();
	void updateModifier();
	std::pair<int,int> getStrength()const;
	std::pair<int,int> getIntelligence()const;
	std::pair<int,int> getDexterity()const;
	std::string getName()override;
	std::vector < std::pair<std::string, int>>& getAbilities()override;
	int getHP()override;
	void subHP(int dammage)override;
	bool rollAbilityCheck(int difficultyClass, std::string ability, std::ofstream& file)override;
	void addHP(int addons);
	void addIntelligence(int addons);
	void addDexterity(int addons);
	void addStrength(int addons);
	~CPlayer();
};

