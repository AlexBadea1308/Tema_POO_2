#include "CRace.h"

CRace::CRace(std::string race_name)
{
	m_race_name = race_name;
}

std::string& CRace::get_race_name()
{
	return m_race_name;
}