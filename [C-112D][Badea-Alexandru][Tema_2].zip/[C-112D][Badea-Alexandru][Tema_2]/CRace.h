#pragma once
#include <string>
class CRace
{
private:
	std::string m_race_name;
public:
	CRace(std::string race_name);
	std::string& get_race_name();
	virtual int getPlusDexterity() { return 0; };
	virtual int getPlusIntelligence() { return 0; };
	virtual int getPlusStrength() { return 0;};
	virtual int getPlusHealth() { return 0; };
	virtual std::pair<std::string, int> getAttackAbility() { return std::make_pair("",0); };
};

