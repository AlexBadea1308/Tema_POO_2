#include "CWizard.h"

int CWizard::getPlusIntelligence()
{
    return m_plus_intelligence;
}

int CWizard::getPlusStrength()
{
    return m_plus_strength;
}

std::pair<std::string, int> CWizard::getAttackAbility()
{
    return m_attack_ability;
}