#pragma once
#include "CClase.h"
class CWizard :public CClase
{
private:
	int m_plus_intelligence;
	int m_plus_strength;
	std::pair<std::string, int> m_attack_ability;
public:
	CWizard(std::string clase_name, int plus_strength, int plus_intelligence) :CClase(clase_name), m_plus_intelligence(plus_intelligence), m_plus_strength(plus_strength), m_attack_ability(std::make_pair("Fireball",40)){}
	int getPlusIntelligence()override;
	int getPlusStrength()override;
	std::pair<std::string, int> getAttackAbility()override;
};

