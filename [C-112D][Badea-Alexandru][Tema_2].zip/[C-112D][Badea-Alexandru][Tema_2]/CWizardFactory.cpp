#include "CWizardFactory.h"

CClase* CWizardFactory::createClase()
{
    return new CWizard("Wizard", 2,-2);
}
