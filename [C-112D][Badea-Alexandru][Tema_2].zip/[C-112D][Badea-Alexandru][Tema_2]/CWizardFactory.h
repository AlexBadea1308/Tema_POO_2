#pragma once
#include "IClaseFactory.h"
#include"CWizard.h"
class CWizardFactory :public IClaseFactory
{
public:
	CClase* createClase()override;
};