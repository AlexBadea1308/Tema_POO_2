#include "IClaseFactory.h"
