#pragma once
#include "CClase.h"
class IClaseFactory
{
public:
	virtual CClase* createClase()=0;
};

