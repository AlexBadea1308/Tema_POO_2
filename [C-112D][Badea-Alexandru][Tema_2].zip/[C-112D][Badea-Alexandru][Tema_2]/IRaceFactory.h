#pragma once
#include"CRace.h"
class IRaceFactory
{
public:
	virtual CRace* createRace() = 0;
};

