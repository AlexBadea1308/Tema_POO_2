﻿#include "SDungeonsDragons.h"
#include"CDwarfFactory.h"
#include"CElfFactory.h"
#include"CFightFactory.h"
#include"CMonkFactory.h"
#include"CHumanFactory.h"
#include"CWizardFactory.h"
#include"ACharacter.h"
#include"CExceptions.h"
#include<iostream>
#include<fstream>
#include<sstream>
#include <chrono>
#include <thread>

SDungeonsDragons& SDungeonsDragons::getInstance(std::ofstream& file)
{
	file <<std::endl<<std::endl<<"<DungeonMaster>:Welcome, brave adventurer, to a world of magic, mystery, and perilous quests.As you step into the realm of adventure,the air is thick with anticipation.The land before you is vastand teeming with possibilities, from ancient dungeons";
	file<<std::endl<<"				filled with untold treasures to enchanted forests shrouded in mystery."<<std::endl;
	file << std::endl << "<DungeonsDragons>:As your Dungeon Master, I shall guide you through this fantastical journey, weaving a tale where your choices shape the destiny of your character. The path you choose may lead to glory or peril, and every decision carries";
	file<<std::endl<<"				consequences.In this realm, dice rolls determine fate, and your character abilitiesand skills will be put to the test.Whether you seek fame, fortune, or the thrill of exploration, the journey begins now."<< std::endl << std::endl;
	if (mp_Instance == NULL)
		mp_Instance = new SDungeonsDragons;
	return *mp_Instance;
}

void SDungeonsDragons::destroyInstance()
{
	if (mp_Instance != NULL)
	{
		delete mp_Instance;
		mp_Instance = NULL;
	}
}

void SDungeonsDragons::createCharacter(std::string character_name,std::string race_type, std::string clase_type,std::ofstream& file)
{
		file<< "<DungeonMaster>:Please chose your character with wisdom, because your life depend on that!" << std::endl << std::endl;
		IRaceFactory* race = NULL;
		IClaseFactory* clase = NULL;
		try
		{
		if (race_type == "Elf")
		{
			race = new CElfFactory();
		}
		else
			if (race_type == "Dwarf")
			{
				race = new CDwarfFactory();
			}
			else
				if (race_type == "Human")
				{
					race = new CHumanFactory();
				}
				else
				{
					throw CExceptions("You chose an unclassified race!",9183873);
				}

		if (clase_type == "Wizard")
		{
			clase = new CWizardFactory();
		}
		else
			if (clase_type == "Fighter")
			{
				clase = new CFightFactory();
			}
			else
				if (clase_type == "Monk")
				{
					clase = new CMonkFactory();
				}
				else
				{
					throw CExceptions("You chose an unclassified clase!", 1266161);
				}
		m_character = new CPlayer(character_name, race->createRace(), clase->createClase());
		file << "<DungeonMaster>:Congratulations my brave adventure you chose like anyone in the past. I'm sure that you will pass all the tests! Good luck " << character_name << "!!!" << std::endl << std::endl;
	}

catch (CExceptions e)
{
	throw;
}
}

void SDungeonsDragons::createEnemy(std::string character_name,int race_type,int clase_type,std::ofstream& file)
{
	IRaceFactory* race = NULL;
	IClaseFactory* clase = NULL;
	if (race_type==0)
	{
		race = new CElfFactory();
	}
	else
		if (race_type ==1)
		{
			race = new CDwarfFactory();
		}
		else
			if (race_type == 2)
			{
				race = new CHumanFactory();
			}

	if (clase_type == 0)
	{
		clase = new CWizardFactory();
	}
	else
		if (clase_type == 1)
		{
			clase = new CFightFactory();
		}
		else
			if (clase_type == 2)
			{
				clase = new CMonkFactory();
			}
	m_enemies.push_back(new CEnemies(character_name, race->createRace(), clase->createClase()));
	m_enemies[0]->displayInfo(file);
}

void SDungeonsDragons::addRacesInformation(std::ofstream& file)
{
	m_races.push_back(CElfFactory().createRace());
	m_races.push_back(CHumanFactory().createRace());
	m_races.push_back(CDwarfFactory().createRace());

	file << "There are all races in the D&D" << std::endl;
	for (std::vector<CRace*>::iterator it = m_races.begin(); it != m_races.end(); it++)
	{
		file << "*" << (*it)->get_race_name() <<std::endl<<"-AttackAbility: "<<(*it)->getAttackAbility().first <<" "<< (*it)->getAttackAbility().second <<std::endl<<"-Plus dexterity: "<<(*it)->getPlusDexterity() <<std::endl<<"-Plus Health: "<<(*it)->getPlusHealth() <<std::endl<<"-Plus intelligence: "<<(*it)->getPlusIntelligence() <<std::endl<<"-Plus strength: "<<(*it)->getPlusStrength() << std::endl<<std::endl;
	}
}

void  SDungeonsDragons::addClasesInformation(std::ofstream& file)
{
	m_clases.push_back(CWizardFactory().createClase());
	m_clases.push_back(CFightFactory().createClase());
	m_clases.push_back(CMonkFactory().createClase());

	file <<std::endl<<"There are all clases in the D&D" << std::endl;
	for (std::vector<CClase*>::iterator it = m_clases.begin(); it != m_clases.end(); it++)
	{
		file << "*" << (*it)->get_clase_name() << std::endl << "-AttackAbility: " << (*it)->getAttackAbility().first << " " << (*it)->getAttackAbility().second << std::endl << "-Plus dexterity: " << (*it)->getPlusDexterity() << std::endl << "-Plus Health: " << (*it)->getPlusHealth() << std::endl << "-Plus intelligence: " << (*it)->getPlusIntelligence() << std::endl << "-Plus strength: " << (*it)->getPlusStrength() << std::endl<<std::endl;
	}

}

CPlayer& SDungeonsDragons::getCharacter()
{
	return *(dynamic_cast<CPlayer*>(m_character));
}

void SDungeonsDragons::loadDungeonFromFile(const std::string& filename, std::ofstream& file)
{	try
	{
		std::vector<std::pair<CAction, std::string>> actions;
		std::ifstream file(filename);
		std::string Dungeon_name;
		if (file.is_open())
		{
			std::string line;
			std::getline(file, Dungeon_name);
			while (std::getline(file, line))
			{
				std::stringstream ss(line);
				std::string name;
				int DC;
				std::string ability;
				std::string object;

				if (ss >> name >> object >> DC >> ability)
				{
					actions.push_back(std::make_pair(CAction(name, object, DC, ability), "NOT DONE YET"));
				}
				else
				{
					throw CExceptions("The content in file directory is harmfull or hasn't the correct pattern!", 65432);
				}
			}
			file.close();
		}
		else
		{
			throw CExceptions("The file didn't exists!", 529189);
		}
		m_dungeons.push_back(new CDungeon(Dungeon_name, actions));
	}

	catch (CExceptions e)
	{
		throw;
	}
}

void SDungeonsDragons::printDungeons(std::ofstream& file)
{
	for (std::vector<CDungeon*>::iterator it=m_dungeons.begin(); it != m_dungeons.end(); it++)
	{
		file << std::endl << (*it)->getDungeonName() << ":" << std::endl;
		for (std::vector<std::pair<CAction,std::string>>::iterator aux =(*it)->getActionsFromDungeon().begin();aux != (*it)->getActionsFromDungeon().end(); aux++)
		{
			file << (*aux).first.getNameAction() <<" <" <<(*aux).first.getNameObject()<<">"<<" roll "<<(*aux).first.getDifficultyClass()<<" "<<(*aux).first.getAbility()<< std::endl;
		}
	}
}

void SDungeonsDragons::enterInDungeon(CDungeon* Dungeon,std::ofstream& file)
{  
		file<< std::endl << "<DungeonMaster>:WELCOME " << m_character->getName() << " in " << Dungeon->getDungeonName() << "!!!" << std::endl << std::endl;
		std::cout<< std::endl << "<DungeonMaster>:WELCOME " << m_character->getName() << " in " << Dungeon->getDungeonName() << "!!!" << std::endl << std::endl;
		while (true)
		{
			std::this_thread::sleep_for(std::chrono::seconds(1));
			file<< "<DungeonMaster>:There are the interactional objects from this dungeon: ";
			std::cout<< "<DungeonMaster>:There are the interactional objects from this dungeon: ";
			int counter = 1;
			for (std::vector<std::pair<CAction, std::string>>::iterator it = Dungeon->getActionsFromDungeon().begin(); it != Dungeon->getActionsFromDungeon().end(); it++)
			{
				if ((*it).second == "NOT DONE YET")
				{
					file <<counter<<"-<" << (*it).first.getNameObject() << "> "; //afisam obiectele cu care putem interactiona
					std::cout<<counter<<"-<"<<(*it).first.getNameObject() << "> ";
				}
				counter++;
			}
			file<< std::endl << std::endl;
			std::cout << std::endl << std::endl;

			file<< "<DungeonMaster>: Please tell me what you want to do now?Enter a number from 1 to "<<Dungeon->getActionsFromDungeon().size()<<", or 0 to leave and loss the game!!!" << std::endl << std::endl;
			std::cout<<"<DungeonMaster>: Please tell me what you want to do now?Enter a number from 1 to " << Dungeon->getActionsFromDungeon().size() << ", or 0 to leave and loss the game!!!" << std::endl << std::endl;

			int choice;
			while (true)
			{
				file<< "<" << m_character->getName() << ">: I choose the number: ";
				std::cout<< "<" << m_character->getName() << ">: I choose the number: ";
				if (std::cin >> choice && choice >= 0 && static_cast<size_t>(choice) <= Dungeon->getActionsFromDungeon().size())//alegem un numar random care este indicele din vectorul de actiuni ale dungeon ului
				{
					break;
				}
				else
				{
					file<< "Invalid choice. Enter a number between 0 and " << Dungeon->getActionsFromDungeon().size() << ": ";
					std::cout<< "Invalid choice. Enter a number between 0 and " << Dungeon->getActionsFromDungeon().size() << ": ";
				}
			}

			if (choice == 0)
			{
				file<< "<DungeonMaster>: " << m_character->getName() << " chose 0 to leave " << Dungeon->getDungeonName() << " and loss the game!" << std::endl << std::endl;
				std::cout << "<DungeonMaster>: " << m_character->getName() << " chose 0 to leave " << Dungeon->getDungeonName() << " and loss the game!" << std::endl << std::endl;
				file<< "--------------------------------------------------------------------------------------------------------------------------------GAMEOVER----------------------------------------------------------------------------------------------------------------------";
				throw CExceptions("You quit the game!", 736542);
			}
			
			//Vedem ce tip de actiune am ales prin choice

			if ((Dungeon->getActionsFromDungeon()[choice - 1].first.getNameObject() == "Book") && (Dungeon->getActionsFromDungeon()[choice - 1].second == "NOT DONE YET"))
			{
				if (performReadAction(Dungeon->getActionsFromDungeon()[choice - 1].first,file) == true)
				{
					Dungeon->getActionsFromDungeon()[choice - 1].second = "DONE"; //daca am reusit sa completam actiunea o marcam ca fiind DONE si data viitoare nu o vom mai putea face din nou(TASK COMPLETED)
				}
			}
			else if ((Dungeon->getActionsFromDungeon()[choice - 1].first.getNameObject() == "Enemy") && (Dungeon->getActionsFromDungeon()[choice - 1].second == "NOT DONE YET"))
			{
				if (performFightAction(Dungeon->getActionsFromDungeon()[choice - 1].first,file) == true)
				{
					Dungeon->getActionsFromDungeon()[choice - 1].second = "DONE"; //daca am reusit sa completam actiunea o marcam ca fiind DONE si data viitoare nu o vom mai putea face din nou(TASK COMPLETED)
				}
				else
				{
					file<< "<DungeonMaster>: " << m_character->getName() << "you lose the game!" << std::endl << std::endl;
					std::cout << "<DungeonMaster>: " << m_character->getName() << "you lose the game!" << std::endl << std::endl;
					file<< "---------------------------------------------------------------------------------------------------------------------------GAMEOVER-----------------------------------------------------------------------------------------------------------------------";
					throw CExceptions("You lose the game against Enemy!", 76254);
				}
			}
			else if ((Dungeon->getActionsFromDungeon()[choice - 1].first.getNameObject() == "BOSS") && (Dungeon->getActionsFromDungeon()[choice - 1].second == "NOT DONE YET"))
			{
				if (performFightAction(Dungeon->getActionsFromDungeon()[choice - 1].first,file) == true)
				{
					Dungeon->getActionsFromDungeon()[choice - 1].second = "DONE"; //daca am reusit sa completam actiunea o marcam ca fiind DONE si data viitoare nu o vom mai putea face din nou(TASK COMPLETED)
					file<<"<DungeonMaster>:YOU FINSIH THE GAME!!! CONGRULATIONS!!!" << std::endl << std::endl;
					std::cout <<"<DungeonMaster>:YOU FINSIH THE GAME!!! CONGRULATIONS!!!" << std::endl << std::endl;
					file << "--------------------------------------------------------------------------------------------------------------------------GAMEOVER------------------------------------------------------------------------------------------------------------------------";
					throw CExceptions("You win the game!!", 1);
				}
				else
				{
					file<< "<DungeonMaster>: " << m_character->getName() << "you lose the game!" << std::endl << std::endl;
					std::cout<< "<DungeonMaster>: " << m_character->getName() << "you lose the game!" << std::endl << std::endl;
					file << "--------------------------------------------------------------------------------------------------------------------------GAMEOVER------------------------------------------------------------------------------------------------------------------------";
					throw CExceptions("You lose the game against BOSS!",-1);
				}
			}
			else if ((Dungeon->getActionsFromDungeon()[choice - 1].first.getNameObject() == "EnchantedMirror") && (Dungeon->getActionsFromDungeon()[choice - 1].second == "NOT DONE YET"))
			{
				if (performInteractAction(Dungeon->getActionsFromDungeon()[choice - 1].first,file) == true)
				{
					Dungeon->getActionsFromDungeon()[choice - 1].second = "DONE"; //daca am reusit sa completam actiunea o marcam ca fiind DONE si data viitoare nu o vom mai putea face din nou(TASK COMPLETED)
				}
			}
			else if ((Dungeon->getActionsFromDungeon()[choice - 1].first.getNameObject() == "LockedGate") && (Dungeon->getActionsFromDungeon()[choice - 1].second == "NOT DONE YET"))
			{
				if (performOpenAction(Dungeon->getActionsFromDungeon()[choice - 1].first,file) == true)
				{
					Dungeon->getActionsFromDungeon()[choice - 1].second = "DONE"; //daca am reusit sa completam actiunea o marcam ca fiind DONE si data viitoare nu o vom mai putea face din nou(TASK COMPLETED)
					file << "<DungeonMaster>: Now you are ready to leave the dungeon!" << std::endl << std::endl;
					std::cout<< "<DungeonMaster>: Now you are ready to leave the dungeon!" << std::endl << std::endl;
					break;
				}
			}
			else if ((Dungeon->getActionsFromDungeon()[choice - 1].first.getNameObject() =="AncientScroll") && (Dungeon->getActionsFromDungeon()[choice - 1].second == "NOT DONE YET"))
			{
				if (performReadAction(Dungeon->getActionsFromDungeon()[choice - 1].first, file) == true)
				{
					Dungeon->getActionsFromDungeon()[choice - 1].second = "DONE"; //daca am reusit sa completam actiunea o marcam ca fiind DONE si data viitoare nu o vom mai putea face din nou(TASK COMPLETED)
				}
			}
			else if ((Dungeon->getActionsFromDungeon()[choice - 1].first.getNameObject() == "MysteriousChest") && (Dungeon->getActionsFromDungeon()[choice - 1].second == "NOT DONE YET"))
			{
				if (performOpenAction(Dungeon->getActionsFromDungeon()[choice - 1].first, file) == true)
				{
					Dungeon->getActionsFromDungeon()[choice - 1].second = "DONE"; //daca am reusit sa completam actiunea o marcam ca fiind DONE si data viitoare nu o vom mai putea face din nou(TASK COMPLETED)
				}
			}
			else
			{
				file << "<DungeonMaster>:You have done it that yet!" << std::endl << std::endl;
				std::cout << "<DungeonMaster>:You have done it that yet!" << std::endl << std::endl;
			}
		}
}

void SDungeonsDragons::interactWithDungeons(std::ofstream& file)
{
		if (m_dungeons.size() == 0)
			throw CExceptions("You failed in assertion dungeons for game!", 928171);
		for (int i = 0; i < m_dungeons.size(); i++)
		{
			SDungeonsDragons::enterInDungeon(m_dungeons[i],file);
		}
}

bool SDungeonsDragons::performReadAction(const CAction& action,std::ofstream& file)
{
	file<< "<DungeonMaster>: You chose to read <" << action.getNameObject() << ">." << std::endl;
	std::cout << "<DungeonMaster>: You chose to read <" << action.getNameObject() << ">." << std::endl;
	std::this_thread::sleep_for(std::chrono::seconds(1));
	if (m_character->rollAbilityCheck(action.getDifficultyClass(),action.getAbility(),file))
	{
		std::this_thread::sleep_for(std::chrono::seconds(1));
		file<< "<DungeonMaster>: You successfully read the " << action.getNameObject() << " and now you boost your intellignece!" << std::endl<<std::endl;
		std::cout<< "<DungeonMaster>: You successfully read the " << action.getNameObject() << " and now you boost your intellignece!" << std::endl<<std::endl;
		CPlayer* m_character1 = dynamic_cast<CPlayer*>(m_character);
		m_character1->addIntelligence(rand() % 3 + 1);
		m_character1->gainExperience(rand()%25+10,file);
		m_character1->updateModifier();
		return true;
	}
	else
	{
		std::this_thread::sleep_for(std::chrono::seconds(1));
		file<<"<DungeonMaster>: You failed to read the " << action.getNameObject() << "." << std::endl<< std::endl;
		std::cout <<"<DungeonMaster>: You failed to read the " << action.getNameObject() << "." << std::endl<< std::endl;
		return false;
	}
}

bool SDungeonsDragons::performFightAction(const CAction& action,std::ofstream& file)
{
	file<<std::endl<<"<DungeonMaster>: You chose to fight <" << action.getNameObject() << ">." << std::endl<<std::endl;
	std::cout <<std::endl<<"<DungeonMaster>: You chose to fight <" << action.getNameObject() << ">." << std::endl<<std::endl;
	int random_race = rand()% m_races.size();
	int random_clase = rand() % m_clases.size();
	SDungeonsDragons::createEnemy(action.getNameObject(), random_race, random_clase,file);

	while(m_character->getHP()>0)
	{ 
		std::this_thread::sleep_for(std::chrono::seconds(1));
		//Acest if este pentru cand caracterul nostru da cu zarul si incearca sa atace inamicul
		if (m_character->rollAbilityCheck(action.getDifficultyClass(), action.getAbility(),file))//Aici verificam daca characterul nostru a dat cu zarul un nr suficient pentru a executa actiunea
		{
			std::this_thread::sleep_for(std::chrono::seconds(1));
			file <<std::endl<<std::endl<<"<DungeonMaster>:There are your abilities: ";
			std::cout << std::endl << std::endl << "<There are your abilities: ";
			int counter = 1;
			for (std::vector<std::pair<std::string,int>>::iterator it =m_character->getAbilities().begin(); it !=m_character->getAbilities().end(); it++)
			{
					file << counter << "-<" << (*it).first<< "> "; //afisam obiectele cu care putem interactiona
					std::cout << counter << "-<" << (*it).first<< "> ";
				counter++;
			}
			file << std::endl << std::endl;
			std::cout << std::endl << std::endl;
			int random_character_ability;
			while (true) //am creat o bucla pentru a alege una din abilitatile de atac pe care le avem la dispozitie
			{
				file << "<" << m_character->getName() << ">: I choose the number: ";
				std::cout << "<" << m_character->getName() << ">: I choose the number: ";
				if (std::cin >> random_character_ability && random_character_ability >=1&& static_cast<size_t>(random_character_ability) <=m_character->getAbilities().size())//alegem un numar random care este indicele din vectorul de actiuni ale dungeon ului
				{
					break;
				}
				else
				{
					file << "Invalid choice. Enter a number between 1 and " << m_character->getAbilities().size() << ": "<<std::endl<<std::endl;
					std::cout << "Invalid choice. Enter a number between 1 and " << m_character->getAbilities().size() << ": "<<std::endl<<std::endl;
				}
			}
			m_enemies[0]->subHP(m_character->getAbilities()[random_character_ability-1].second);// ii scadem inamicului dammage abilitatii charcaterului ales random
			file<< "<DungeonMaster>: You hit the " <<m_enemies[0]->getName()<< " with " << m_character->getAbilities()[random_character_ability-1].first << std::endl;
			std::cout << "<DungeonMaster>: You hit the " <<m_enemies[0]->getName()<< " with " << m_character->getAbilities()[random_character_ability-1].first << std::endl;
			std::this_thread::sleep_for(std::chrono::seconds(1));
			if (m_enemies[0]->getHP() < 0) //daca inamicul nu mai are HP afisam mesajele de mai jos si ii atribuim characterului nostru ce a castigat dupa urmarea confruntarii(upgrade-uri)
			{
				file<< "<DungeonMaster>: " << m_enemies[0]->getName() << " has now 0 hp!" << std::endl << std::endl;
				std::cout << "<DungeonMaster>: " << m_enemies[0]->getName() << " has now 0 hp!" << std::endl << std::endl;
				std::this_thread::sleep_for(std::chrono::seconds(1));
				file<< "<DungeonMaster>:Congratulations you win against " << m_enemies[0]->getName() << std::endl << std::endl;
				std::cout << "<DungeonMaster>:Congratulations you win against " << m_enemies[0]->getName() << std::endl << std::endl;
				std::this_thread::sleep_for(std::chrono::seconds(1));
				CPlayer* m_character1 = dynamic_cast<CPlayer*>(m_character);
				m_character1->addHP(rand() % 20);
				m_character1->levelUp(file);
				m_character1->addStrength(rand() % 3 + 1);
				m_character1->updateModifier();
				m_enemies.clear();
				return true;
			}
			else
			{
				file << "<DungeonMaster>: " << m_enemies[0]->getName() << " has now " << m_enemies[0]->getHP() << " hp!" << std::endl << std::endl;
				std::cout << "<DungeonMaster>: " << m_enemies[0]->getName() << " has now " << m_enemies[0]->getHP() << " hp!" << std::endl << std::endl;
				std::this_thread::sleep_for(std::chrono::seconds(1));
			}
		}
		else //mesaje in caz ca characterul nostru nu da cu zarul cat este nevoie 
		{
			file<<"<DungeonMaster>: You missed the " << action.getNameObject() << ".And now it is " << m_enemies[0]->getName() << " turn to attack!" << std::endl;
			std::cout <<"<DungeonMaster>: You missed the " << action.getNameObject() << ".And now it is " << m_enemies[0]->getName() << " turn to attack!" << std::endl;
			std::this_thread::sleep_for(std::chrono::seconds(1));
			file << "<" << m_enemies[0]->getName() << ">:HAHAAA you missed now you will fell my power!!!" << std::endl<<std::endl;
			std::cout << "<" << m_enemies[0]->getName() << ">:HAHAAA you missed now you will fell my power!!!" << std::endl<<std::endl;		
			std::this_thread::sleep_for(std::chrono::seconds(1));

		}

		std::this_thread::sleep_for(std::chrono::seconds(1));

		//Acest if este pentru cand inamoicul da cu zarul si incearca sa atace carcaterul nostru
		if (m_enemies[0]->rollAbilityCheck(action.getDifficultyClass(), action.getAbility(),file))
		{
			std::this_thread::sleep_for(std::chrono::seconds(1));
			int random_enemy_ability = rand() % m_enemies[0]->getAbilities().size();
			m_character->subHP(m_enemies[0]->getAbilities()[random_enemy_ability].second);// ii scadem inamicului dammage abilitatii charcaterului ales random
			file << "<DungeonMaster>:" << m_enemies[0]->getName() << " hit you with " << m_enemies[0]->getAbilities()[random_enemy_ability].first << std::endl;
			std::cout << "<DungeonMaster>:" << m_enemies[0]->getName() << " hit you with " << m_enemies[0]->getAbilities()[random_enemy_ability].first << std::endl;
			std::this_thread::sleep_for(std::chrono::seconds(1));
			if (m_character->getHP() < 0)
			{
				file << "<DungeonMaster>:" << m_character->getName() << " has now 0 hp!" << std::endl << std::endl;
				std::cout << "<DungeonMaster>:" << m_character->getName() << " has now 0 hp!" << std::endl << std::endl;
				std::this_thread::sleep_for(std::chrono::seconds(1));
				return false;
			}
			else
			{
				file << "<DungeonMaster>:" << m_character->getName() << " has now " << m_character->getHP() << " hp!" << std::endl << std::endl;
				std::cout << "<DungeonMaster>:" << m_character->getName() << " has now " << m_character->getHP() << " hp!" << std::endl << std::endl;
				std::this_thread::sleep_for(std::chrono::seconds(1));
			}
		}
		else
		{
			file << "<DungeonMaster>:"<<m_enemies[0]->getName()<<" missed the " <<m_character->getName()<< ".And now it is " << m_character->getName() << " turn to attack!" << std::endl;
			std::cout << "<DungeonMaster>:"<<m_enemies[0]->getName()<<" missed the " <<m_character->getName()<< ".And now it is " << m_character->getName() << " turn to attack!" << std::endl;
			std::this_thread::sleep_for(std::chrono::seconds(1));
			file << "<" <<m_character->getName() << ">:You should have aimed for the head!!!" << std::endl<<std::endl;
			std::cout << "<" <<m_character->getName() << ">:You should have aimed for the head!!!" << std::endl<<std::endl;
			std::this_thread::sleep_for(std::chrono::seconds(1));
		}
	}
	return false;
}

bool SDungeonsDragons::performOpenAction(const CAction& action,std::ofstream& file)
{
	file << "<DungeonMaster>: You chose to open <" << action.getNameObject() << ">." << std::endl;
	std::cout << "<DungeonMaster>: You chose to open <" << action.getNameObject() << ">." << std::endl;
	std::this_thread::sleep_for(std::chrono::seconds(1));
	if (m_character->rollAbilityCheck(action.getDifficultyClass(), action.getAbility(),file))
	{
		std::this_thread::sleep_for(std::chrono::seconds(1));
		file << "<DungeonMaster>: You successfully open the " << action.getNameObject()<<std::endl<<std::endl;
		std::cout << "<DungeonMaster>: You successfully open the " << action.getNameObject() << std::endl << std::endl;
		return true;
	}
	else
	{
		std::this_thread::sleep_for(std::chrono::seconds(1));
		file << "<DungeonMaster>: You failed to open the " << action.getNameObject() << "." << std::endl << std::endl;
		std::cout << "<DungeonMaster>: You failed to open the " << action.getNameObject() << "." << std::endl << std::endl;
		return false;
	}
}

bool SDungeonsDragons::performInteractAction(const CAction& action,std::ofstream& file)
{
	file << "<DungeonMaster>: You chose to read <" << action.getNameObject() << ">." << std::endl;
	std::cout << "<DungeonMaster>: You chose to read <" << action.getNameObject() << ">." << std::endl;
	std::this_thread::sleep_for(std::chrono::seconds(1));
	if (m_character->rollAbilityCheck(action.getDifficultyClass(), action.getAbility(),file))
	{
		std::this_thread::sleep_for(std::chrono::seconds(1));
		file << "<DungeonMaster>: You successfully interact the " << action.getNameObject() << " and find a new ability! <RKO,25 dammage>" << std::endl << std::endl;
		std::cout << "<DungeonMaster>: You successfully interact the " << action.getNameObject() << " and find a new ability! <RKO,25 dammage>" << std::endl << std::endl;
		m_character->getAbilities().push_back(std::make_pair("RKO", 25));
		CPlayer* m_character1 = dynamic_cast<CPlayer*>(m_character);
		m_character1->gainExperience(rand() % 25 + 10,file);
		return true;
	}
	else
	{
		std::this_thread::sleep_for(std::chrono::seconds(1));
		file << "<DungeonMaster>: You failed to interact the " << action.getNameObject() << "." << std::endl << std::endl;
		std::cout << "<DungeonMaster>: You failed to interact the " << action.getNameObject() << "." << std::endl << std::endl;
		return false;
	}
}