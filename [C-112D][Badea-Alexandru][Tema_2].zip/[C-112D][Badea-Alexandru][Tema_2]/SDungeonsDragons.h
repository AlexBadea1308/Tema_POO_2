#pragma once
#include "CPlayer.h"
#include"CDungeon.h"
#include"CEnemies.h"
#include "SLogger.h"
#include<string>
#include <cstdlib>
#include <ctime>
class SDungeonsDragons
{
private:
	static SDungeonsDragons* mp_Instance;
	ACharacter* m_character;
	std::vector<CRace*>m_races;
	std::vector<CClase*>m_clases;
	std::vector<CDungeon*> m_dungeons;
	std::vector<ACharacter*>m_enemies;
	SDungeonsDragons(){};
	~SDungeonsDragons(){};
	SDungeonsDragons(const SDungeonsDragons& obj){};
public:
	static SDungeonsDragons& getInstance(std::ofstream& file);
	static void destroyInstance();
	void createCharacter(std::string character_name, std::string race_type, std::string clase_type,std::ofstream& file);
	void createEnemy(std::string character_name,int race,int clase, std::ofstream& file);
	void addRacesInformation(std::ofstream& file);
	void addClasesInformation(std::ofstream& file);
	CPlayer& getCharacter();
	void loadDungeonFromFile(const std::string& filename, std::ofstream& file);
	void printDungeons(std::ofstream& file);
	void interactWithDungeons(std::ofstream& file);
	void enterInDungeon(CDungeon* Dungeon,std::ofstream& file);
	bool performReadAction(const CAction &action,std::ofstream& file);
	bool performFightAction(const CAction& action,std::ofstream& file);
	bool performOpenAction(const CAction& action,std::ofstream& file);
	bool performInteractAction(const CAction& action,std::ofstream& file);
};

