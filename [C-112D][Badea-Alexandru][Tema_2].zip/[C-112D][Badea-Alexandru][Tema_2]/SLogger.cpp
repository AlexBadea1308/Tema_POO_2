#include "SLogger.h"

SLogger& SLogger::getInstance(std::ofstream& fileStream)
{
	if (mp_Instance == NULL)
	{
		mp_Instance = new SLogger(fileStream);
	}
	return *mp_Instance;
}

void SLogger::destroyInstance()
{
	if (mp_Instance != NULL)
	{
		delete mp_Instance;
		mp_Instance == NULL;
	}
}

std::ofstream& SLogger::getScenary()
{
	return m_scenary;
}