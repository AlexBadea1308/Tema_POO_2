#pragma once
#include<fstream>
class SLogger
{
private:
	static SLogger* mp_Instance;
	std::ofstream& m_scenary;
	SLogger(std::ofstream& filestream):m_scenary(filestream){}
	~SLogger(){};
	SLogger(const SLogger& obj);
public:
	static SLogger& getInstance(std::ofstream& filestream);
	static void destroyInstance();
	std::ofstream& getScenary();
};

