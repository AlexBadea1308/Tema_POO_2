#include<iostream>
#include<fstream>
#include "CPlayer.h"
#include"CClase.h"
#include"CRace.h"
#include "SDungeonsDragons.h"
#include "CExceptions.h"
#include "SLogger.h"

SDungeonsDragons* SDungeonsDragons::mp_Instance = NULL;
SLogger* SLogger::mp_Instance = NULL;

//Modul in care am gandit mecanica jocului:
//In fiecare dungeon eroul are obiecte cu care sa interactioneze si neaparat unul dintre ele este un LockGate care practic este usa catre noul dungeon
//Ca sa poti termina jocul trebuie sa ajumgi in ultimul dungeon unde o sa poti interactiona cu BOSS
//Indiferent de rezultat jocul se va termina (WIN OR LOSE)


int main(int argc,char* argv[])
{  
	std::ofstream outputfile("log.txt");
	if (!outputfile.is_open())
	{
		throw CExceptions("Error open the outputfile directory!", 76543);
	}
	SLogger& Logger = SLogger::getInstance(outputfile);
	try
   {
		Logger.getScenary()<<"------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------" << std::endl;
		Logger.getScenary()<< "																											WELCOME TO DUNGEONS AND DRAGONS GAME" << std::endl;
		srand(time(0));
		SDungeonsDragons& DungeonMaster=SDungeonsDragons::getInstance(Logger.getScenary());
		DungeonMaster.addRacesInformation(Logger.getScenary());//salvam informatiile despre rase
		DungeonMaster.addClasesInformation(Logger.getScenary());//salvam infomratiile despre clase
		DungeonMaster.createCharacter("Garik Bronleif", "Human", "Fighter", Logger.getScenary());    //!!!! Aici ne creem caracterul cu ce rasa si clasa dorim
		DungeonMaster.getCharacter().updateAbilities();
		DungeonMaster.getCharacter().updateModifier();//calculam modifier urile pentru fiecare abilitate in parte
		DungeonMaster.getCharacter().displayInfo(Logger.getScenary());//indormatiile despre caracter

		Logger.getScenary()<< std::endl << "<DungeonMaster>:LET THE JPURNEY BEGIN MY BRAVE ADVENTURE!" << std::endl;

		for (int i = 1; i < argc; i++)// am folosit argv si argc pentru a da fisierele text (dungeon urile prin care trebuie sa treaca caracterul nostru)
		{
			DungeonMaster.loadDungeonFromFile(argv[i],Logger.getScenary());
		}
		DungeonMaster.interactWithDungeons(Logger.getScenary());//incepem sa intram in fiecare dungeon si sa alegem ce interactiuni dorim sa avem
		DungeonMaster.destroyInstance();
		Logger.getScenary().close();
		Logger.destroyInstance();
	}
	catch (CExceptions& e)
	{
		Logger.getScenary().close();
		Logger.destroyInstance();
		e.printErrorMessage(Logger.getScenary());
	}
	catch (...)
	{
		Logger.getScenary()<< "Unhandled exceptions!" << std::endl << std::endl;
	}

	return 0;
}